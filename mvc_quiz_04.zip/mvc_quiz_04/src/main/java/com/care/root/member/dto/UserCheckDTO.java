package com.care.root.member.dto;


public class UserCheckDTO {
	private int chk;
	private String name;
	
	public int getChk() {
		return chk;
	}
	public void setChk(int chk) {
		this.chk = chk;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}