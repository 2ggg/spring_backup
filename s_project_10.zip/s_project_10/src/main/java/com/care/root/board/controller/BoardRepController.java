package com.care.root.board.controller;

public class BoardRepController {

}
