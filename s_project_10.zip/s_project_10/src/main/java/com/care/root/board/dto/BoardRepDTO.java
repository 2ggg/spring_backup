package com.care.root.board.dto;

public class BoardRepDTO {

}
