package com.care.root.board.service;

public interface BoardFileService {

}
