package com.care.root.board.service;

public class BoardFileServiceImpl {

}
