package com.care.root.board.service;

import org.springframework.ui.Model;

public interface BoardService {
	public void selectAllBoardList(Model model);
}
