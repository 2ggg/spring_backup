package com.care.root.common;

public interface MemberSessionName {
	// 로그인 성공시 생성되는 세션 이름
	static final String LOGIN = "loginUser";
}
